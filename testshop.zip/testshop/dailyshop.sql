-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2023 at 09:04 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dailyshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'HP'),
(2, 'DELL'),
(3, 'LENOVO'),
(4, 'Sony'),
(5, 'Nintendo'),
(6, 'Samsung'),
(7, 'Asus'),
(8, 'Apple'),
(9, 'Huawei'),
(10, 'NOKIA'),
(11, 'NIKON'),
(12, 'Play Station'),
(13, 'Xbox');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `p_id` int(11) DEFAULT NULL,
  `ip_add` varchar(16) DEFAULT NULL,
  `qty` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_title`) VALUES
(1, 'Shop'),
(2, 'Event');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `p_id` int(11) DEFAULT NULL,
  `c_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `p_id`, `c_id`, `qty`) VALUES
(1, 11, 2, 1),
(2, 5, 2, 1),
(3, 12, 2, 1),
(4, 8, 2, 1),
(5, 4, 5, 3),
(6, 2, 4, 3),
(7, 8, 6, 1),
(8, 1, 7, 1),
(9, 3, 8, 2),
(10, 5, 9, 4),
(11, 3, 1, 5),
(12, 1, 1, 1),
(13, 9, 1, 1),
(14, 10, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `product_title` text NOT NULL,
  `product_img1` text DEFAULT NULL,
  `product_img2` text DEFAULT NULL,
  `product_img3` text DEFAULT NULL,
  `price` int(11) NOT NULL,
  `product_desc` text DEFAULT NULL,
  `status` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `cat_id`, `brand_id`, `date`, `product_title`, `product_img1`, `product_img2`, `product_img3`, `price`, `product_desc`, `status`) VALUES
(8, 1, 2, '2023-06-28 22:36:04', 'Dell Inspiron 13 Convertible Core i7-6500U FHD Touch', 'Inspiron-13-7353.jpg', '', '', 800, 'Specifications\r\n\r\nProcessor\r\n6th Generation IntelÂ® Coreâ„¢ i7-6500U (2.5GHz Turbo Boost upto 3.1GHz)\r\nDisplay\r\n13.3\" Full HD LED x360 Convertible Touch Screen (1920x1080)\r\nStorage\r\n256GB 5400rpm SSD SATA\r\nRam\r\n8GB DDR3L\r\nOperating System\r\nGenuine Windows 10 (64-bit)\r\nGraphics Card\r\nIntel HD 520 Shared\r\nExtra Features\r\nTouch Screen, FHD', 'on'),
(9, 1, 1, '2023-06-28 22:36:54', 'HP Probook 440 G3 Core i7-6500U 1TB 8GB 2GB-GC ', 'Probook-440-G3.jpg', '', '', 910, 'Specifications\r\n\r\nProcessor\r\n6th Generation IntelÂ® Coreâ„¢ i7-6500U (2.5 GHz Turbo Boost 3.1 GHz)\r\nDisplay\r\n14\" diagonal HD anti-glare flat LED-backlite (1366 x 768)\r\nStorage\r\n1 TB 5400 rpm SATA\r\nRam\r\n8 GB DDR3L\r\nOperating System\r\nFreeDOS 2.0\r\nGraphics Card\r\nAMD Radeonâ„¢ R7 M340 ( 2 GB DDR3 dedicated, switchable)\r\nExtra Features\r\nFinger Print Reader', 'on'),
(10, 2, 6, '2023-06-28 22:47:49', 'Samsung 32J5100 32\" Full HD Flat LED', '32J5100.jpg', '', '', 490, 'More vibrant colours for better images\r\nBringing a full multimedia experience into your living room with HDMI\r\nWatch movies from your USB', 'on'),
(11, 2, 4, '2023-06-28 22:48:35', 'Sony Bravia 40\" KDL-R562C LED', 'KDL-R562C.jpg', '', '', 690, 'Connect with great entertainment with Built-in Wi-FiÂ®\r\nClear Resolution Enhancer\r\nMotion flow XR 100hz\r\nFlatter any living space with beautiful styling and class-leading slimness.\r\nYouTubeâ„¢ and more', 'on');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD KEY `p_id` (`p_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `c_id` (`c_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `brand_id` (`brand_id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
